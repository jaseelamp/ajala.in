# Ajala Graphics & Printers

Standalone HTML, Bootstrap 5.3.3, CSS and vanilla JavaScript conversion of the supplied Ajala reference website.

## Open the website

Open `index.html` directly in a browser. No installation or build is required.

On macOS, double-click `start-preview.command` to start the local preview. Keep its Terminal window open while using the preview; restart it if the local URL says the site cannot be reached.

For a local web preview, run this command from this folder:

```sh
python3 -m http.server 8765 --bind 127.0.0.1
```

Then open http://127.0.0.1:8765.

## Included

- Home, About, Services, Our Work, Contact and Get a Quote.
- All seven individual service pages.
- Original text, logo, CSS artwork, image, colours and responsive layouts.
- Bootstrap mobile navigation and FAQ accordions.
- Portfolio category filters, draggable desk pieces, floating artwork, counters, reveals and the scroll-driven production journey.
- Four-colour page transitions and animated headings on every inner-page banner, with reduced-motion support.
- Quote service preselection, required-field validation, and WhatsApp enquiry drafts.
- Local font files, Bootstrap assets and the letterpress photograph.

The reference's sample portfolio artwork and testimonial placeholders are intentionally preserved.

## Files

- `index.html`, other root HTML files, and `services/*.html`: editable standalone pages.
- `assets/css/original.css`: the original compiled design stylesheet. It needs no Tailwind runtime or build tool.
- `assets/css/site.css`: Bootstrap integration and interaction styles.
- `assets/css/bootstrap-layer.css`: Bootstrap CSS placed in a lower-priority cascade layer to preserve the original design.
- `assets/js/site.js`: plain JavaScript interactions and WhatsApp form handling.
- `assets/fonts/`, `assets/images/`, `vendor/`: local assets.

No React, application server, database or npm installation is required. WhatsApp, Google Maps and external social links require internet access. Forms open a WhatsApp draft; the visitor presses Send in WhatsApp.

The workspace also contains original DOM captures in `reference/` and `home-reference.html`, plus an optional `scripts/build.py` maintenance script. Running that script regenerates the HTML from the captures and overwrites manual HTML edits. These maintenance files are not required to host the site.

## Reference and third-party assets

Reference: https://ajala-graphics.preview.emergentagent.com

Bootstrap is distributed under the MIT license; its copyright notice is retained in the vendor files. The compiled reference stylesheet retains its Tailwind MIT notice. Font families are Manrope, Space Grotesk, Playfair Display and IBM Plex Mono from Google Fonts. The photograph is the same Unsplash image used by the reference.

Upload the HTML files, `services/`, `assets/` and `vendor/` to any static web host. Keep their relative paths intact. `ajala-html-bootstrap.zip` contains the ready-to-host files.
