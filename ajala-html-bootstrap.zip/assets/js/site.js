/* Ajala — plain JavaScript. Bootstrap handles disclosure components. */
(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const header = $('[data-testid="site-header"]');
  const menu = $('#mobile-menu');
  const menuButton = $('[data-testid="header-menu-button"]');

  // Preserve the original four-colour wipe across real HTML navigation.
  // CSS also finishes the entrance without JavaScript, so it cannot hide a page.
  const curtain = $('[data-page-transition]');
  let leaving = false;
  let navigateTimer;
  const resetTransition = () => {
    clearTimeout(navigateTimer);
    leaving = false;
    curtain?.classList.remove('is-entering', 'is-leaving');
  };
  curtain?.addEventListener('animationend', event => {
    if (event.animationName === 'curtain-reveal' && event.target === curtain.lastElementChild && !leaving) {
      curtain.classList.remove('is-entering');
    }
  });
  addEventListener('pageshow', event => { if(event.persisted) resetTransition(); });
  document.addEventListener('click', event => {
    if (!curtain || reduceMotion || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest('a[href]');
    if (!link || link.hasAttribute('download') || (link.target && link.target !== '_self')) return;
    const destination = new URL(link.href, location.href);
    if (destination.origin !== location.origin || !/\.html$/i.test(destination.pathname)) return;
    if (destination.pathname === location.pathname && destination.search === location.search) return;
    event.preventDefault();
    if (leaving) return;
    leaving = true;
    curtain.classList.remove('is-entering');
    curtain.classList.add('is-leaving');
    navigateTimer = setTimeout(() => {
      location.assign(destination.href);
      // Recover if the browser cancels navigation instead of unloading.
      navigateTimer = setTimeout(resetTransition, 3000);
    }, 570);
  });

  // Full-screen mobile navigation uses Bootstrap Collapse.
  if (menu && menuButton) {
    const originalIcon = menuButton.innerHTML;
    const closeIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';
    menu.addEventListener('show.bs.collapse', () => {
      document.body.classList.add('menu-open');
      menuButton.setAttribute('aria-label', 'Close menu');
      menuButton.innerHTML = closeIcon;
    });
    menu.addEventListener('hide.bs.collapse', () => {
      document.body.classList.remove('menu-open');
      menuButton.setAttribute('aria-label', 'Open menu');
      menuButton.innerHTML = originalIcon;
    });
    const closeMenu = () => bootstrap.Collapse.getOrCreateInstance(menu, {toggle:false}).hide();
    menu.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
    document.addEventListener('keydown', event => {
      if (!menu.classList.contains('show')) return;
      if (event.key === 'Escape') { closeMenu(); menuButton.focus(); }
      if (event.key === 'Tab') {
        const controls = [menuButton, ...$$('a', menu)];
        const first = controls[0], last = controls.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    });
    matchMedia('(min-width:1024px)').addEventListener('change', event => { if(event.matches) closeMenu(); });
  }

  // Progressive reveal: content is visible when JavaScript is unavailable.
  if (!reduceMotion && 'IntersectionObserver' in window) {
    const reveal = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.remove('reveal-pending');
      entry.target.classList.add('reveal-visible');
      reveal.unobserve(entry.target);
    }), {threshold: .06});
    $$('[data-reveal]').forEach(element => {
      element.classList.add('reveal-pending');
      reveal.observe(element);
    });
  }

  // Count the original studio statistics when they enter the viewport.
  if ('IntersectionObserver' in window) {
    const counts = new IntersectionObserver(entries => entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      counts.unobserve(entry.target);
      const el=entry.target, value=el.dataset.count, number=parseInt(value,10), suffix=value.replace(/\d/g,'');
      if (reduceMotion) return;
      const start=performance.now();
      const tick = now => {
        const progress=Math.min(1,(now-start)/1200);
        el.textContent = Math.round(number*(1-Math.pow(1-progress,3)))+suffix;
        if(progress<1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }), {threshold:.4});
    $$('[data-count]').forEach(el=>counts.observe(el));
  }

  // Scroll-driven production journey and its colour progress line.
  const journey=$('[data-testid="idea-to-print-section"]');
  const track=journey && $('[data-testid="journey-panel-01"]',journey).parentElement;
  const progressBar=journey && $('.origin-left',journey);
  const process=$('[data-testid="process-section"]');
  const pageProgress=$$('.grain > .fixed > .relative > .origin-left');
  let scheduled=false;
  function updateScroll() {
    scheduled=false;
    header?.classList.toggle('is-scrolled',window.scrollY>24);
    const overall=window.scrollY/Math.max(1,document.documentElement.scrollHeight-innerHeight);
    pageProgress.forEach((bar,i)=>bar.style.transform=`scaleX(${Math.max(0,Math.min(1,overall*4-i))})`);
    if(journey) {
      const bounds=journey.getBoundingClientRect();
      const progress=Math.max(0,Math.min(1,-bounds.top/(journey.offsetHeight-innerHeight)));
      track.style.transform=`translate3d(${-progress*(track.children.length-1)*innerWidth}px,0,0)`;
      progressBar.style.transform=`scaleX(${.25+.75*progress})`;
    }
    if(process) {
      const fraction=Math.max(0,Math.min(1,(innerHeight*.8-process.getBoundingClientRect().top)/(process.offsetHeight*.8)));
      $$('[style*="scaleX"]',process).forEach(el=>el.style.transform=`scaleX(${fraction})`);
    }
  }
  function scheduleScroll() { if(!scheduled) {scheduled=true;requestAnimationFrame(updateScroll);} }
  addEventListener('scroll',scheduleScroll,{passive:true});
  addEventListener('resize',scheduleScroll,{passive:true});
  updateScroll();

  // Pointer capture keeps the draggable print pieces attached to the pointer.
  $$('[data-draggable]').forEach((piece,index)=>{
    const rotation=piece.style.transform.match(/rotate\([^)]+\)/)?.[0] || '';
    let x=0,y=0,startX=0,startY=0,dragging=false;
    piece.addEventListener('pointerdown',event=>{
      if(event.button!==0) return;
      dragging=true; startX=event.clientX-x;startY=event.clientY-y;
      piece.setPointerCapture(event.pointerId);
      piece.classList.add('is-dragging');
      piece.parentElement.parentElement.style.zIndex='20';
      event.preventDefault();
    });
    piece.addEventListener('pointermove',event=>{
      if(!dragging)return;
      x=Math.max(-180,Math.min(180,event.clientX-startX));
      y=Math.max(-160,Math.min(160,event.clientY-startY));
      piece.style.transform=`translate(${x}px,${y}px) ${rotation}`;
    });
    const end=()=>{ dragging=false;piece.classList.remove('is-dragging');piece.parentElement.parentElement.style.zIndex=''; };
    piece.addEventListener('pointerup',end);
    piece.addEventListener('pointercancel',end);
    piece.addEventListener('lostpointercapture',end);
    if(!reduceMotion) {
      piece.parentElement.style.animation=`float-soft ${6+index*.7}s ease-in-out ${index*-.8}s infinite`;
    }
  });

  // The twelve original portfolio cards are filtered entirely on the client.
  const filters=$$('[data-filter]'), cards=$$('[data-category]');
  const activeFilterClass=filters.find(button=>button.getAttribute('aria-pressed')==='true')?.className;
  const inactiveFilterClass=filters.find(button=>button.getAttribute('aria-pressed')==='false')?.className;
  filters.forEach(button=>button.addEventListener('click',()=>{
    filters.forEach(filter=>{
      filter.setAttribute('aria-pressed',String(filter===button));
      filter.className=filter===button?activeFilterClass:inactiveFilterClass;
    });
    cards.forEach(card=>{
      card.hidden=button.dataset.filter!=='All' && card.dataset.category!==button.dataset.filter;
      if(!card.hidden) {
        card.classList.remove('reveal-pending');
        if(!reduceMotion) card.animate([{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'none'}],{duration:300});
      }
    });
  }));

  if(!reduceMotion && matchMedia('(hover:hover)').matches) {
    const cursors=$$('.grain > [aria-hidden="true"][class*="z-[95]"]');
    document.addEventListener('pointermove',event=>{
      cursors.forEach(cursor=>cursor.style.transform=`translate(${event.clientX}px,${event.clientY}px) translate(-50%,-50%)`);
    },{passive:true});
    document.addEventListener('pointerleave',()=>cursors.forEach(cursor=>cursor.style.transform='translate(-100px,-100px)'));
    $$('[data-tilt]').forEach(card=>{
      card.addEventListener('pointermove',event=>{
        const box=card.getBoundingClientRect();
        const rx=((event.clientY-box.top)/box.height-.5)*-5;
        const ry=((event.clientX-box.left)/box.width-.5)*5;
        card.style.transform=`perspective(1000px) rotateX(${rx}deg) rotateY(${ry}deg)`;
      });
      card.addEventListener('pointerleave',()=>card.style.transform='perspective(1000px)');
    });
  }

  // Match the source workflow: validate, open a draft in WhatsApp, then the
  // visitor decides whether to send. Nothing is posted to a server here.
  const form=$('[data-whatsapp-form]');
  if(form) {
    const service=$('select',form);
    const selected=new URLSearchParams(location.search).get('service');
    if(selected && service) {
      const option=[...service.options].find(o=>o.value===selected || o.textContent.toLowerCase().replace(/\s*&\s*/g,'-').replace(/\s+/g,'-')===selected);
      if(option) service.value=option.value;
    }
    form.addEventListener('submit',event=>{
      event.preventDefault();
      if(!form.reportValidity()) return;
      const isQuote=form.dataset.whatsappForm==='quote';
      const lines=[isQuote?'Hi Ajala Graphics, I would like to request a quote.':'Hi Ajala Graphics, I have an enquiry.',''];
      $$('input,select,textarea',form).forEach(field=>{
        const value=field.value.trim();
        if(!value) return;
        const label=field.labels?.[0]?.textContent.replace(/\s*\*\s*$/,'').trim() || field.name;
        lines.push(`${label}: ${value}`);
      });
      const href='https://wa.me/919447011931?text='+encodeURIComponent(lines.join('\n'));
      window.open(href,'_blank','noopener,noreferrer');
    });
  }
})();
