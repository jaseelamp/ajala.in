#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
printf '\nAjala preview: http://127.0.0.1:8765/\nKeep this window open while viewing the site. Press Control-C to stop.\n\n'
python3 -m http.server 8765 --bind 127.0.0.1
